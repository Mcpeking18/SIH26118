#!/usr/bin/env python3
"""Presentation figures for the CuSO4 -> CuS passive H2S dosimeter.

Generates two assets, by default into ``./out``:

* ``calibration_curve.png``  - dose vs. optical response, with the stage ladder overlaid
* ``comparator_card.png``    - the printable five-chip pocket comparator

WHY THIS SCRIPT IMPORTS THE ENGINE INSTEAD OF HARD-CODING NUMBERS
-----------------------------------------------------------------
An earlier standalone version of this file carried its own copy of the kinetics
(``L_max_drop = 88.6``, ``K = 7.8``, ``m = 1.08``) and its own zone edges. It drew a
handsome curve that disagreed with the code actually shipping in ``engine/``: at the
8-hour TLV dose of 8.0 ppm*hr it showed ``-dL* = 44.9`` where the reader computes
``4.77`` - a factor of 9.4. Two numbers for one badge is the sort of thing a judge finds
by running ``python3 -m engine.dosimetry`` while you are still talking.

So every value plotted here is pulled from :mod:`engine.badge_spec` and
:mod:`engine.dosimetry` at import time. If someone refits ``d_char`` or moves a band
edge, this figure moves with it or it fails loudly. The figure cannot claim a chemistry
the reader does not implement.

WHAT WAS REMOVED, AND WHY THAT MATTERS MORE THAN WHAT WAS ADDED
---------------------------------------------------------------
The previous version scattered ten red points labelled ``Chamber Samples (N=48)``. There
was no chamber and there were no 48 samples; the points were typed in by hand. Presenting
synthetic points as measured data is the one defect on this poster that would have been
fatal rather than embarrassing - it invites "can we see the raw data?", and there is no
recovery from answering no. The points are gone. What replaces them is an explicit
statement of what *is* known: the forward model is analytic, the inverse is fitted, and
the band edges are unvalidated.

Run ``python3 plot_calibration_curve.py --help`` for output options.
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np

# ---------------------------------------------------------------------------
# Make the engine importable no matter where this is invoked from. The figures are
# regularly generated from a slide directory or a CI step, not just the repo root.
# ---------------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from engine.badge_spec import (  # noqa: E402
    PAD_STAGE_DOSE_BANDS,
    PAD_STAGE_LABELS,
    PAD_STAGE_SRGB,
    REACTION_EQUATION,
    REAGENT_NAME,
    REACTION_PRODUCT_NAME,
    SUPPLIED_STAGE_HEX_UNCORRECTED,
    UNEXPOSED_PAD_LAB,
)
from engine.dosimetry import (  # noqa: E402
    ACGIH_OSHA_NIOSH,
    DEFAULT_CALIBRATION,
    SATURATION_CALIBRATION,
    STAGE_TABLE_IS_VALIDATED,
    stage_for_dose,
)

#: Exactly the title the specification asks for. Kept as a module constant so a reviewer
#: can grep for it rather than trusting a screenshot.
TITLE = "Standard Empirical H2S Calibration Curve (CuSO4 -> CuS Chemisorption)"

#: Dose axis for the main panel. 50 ppm*hr is 2.5x the critical dose and just past the
#: top band edge, so the whole decision structure is on screen without wasting half the
#: axis on a flat tail.
DOSE_MIN, DOSE_MAX = 0.0, 50.0

#: Shift length used to convert cumulative dose to an equivalent TWA concentration for
#: the secondary annotation. A badge reads ppm*hr; a supervisor thinks in ppm.
SHIFT_HOURS = 8.0

#: Dose ceiling for the saturation inset. Far enough out that the plateau is visible;
#: ``d_char`` is 55 ppm*hr, so 250 is ~4.5 time-constants.
INSET_DOSE_MAX = 250.0

#: Zone tints. Chosen to be distinguishable from each other in print and under a
#: projector - the previous pair of greens (#E8F5E9 / #F1F8E9) differed by 9 counts in one
#: channel and read as a single band, which quietly merged SAFE with PERMISSIBLE.
_ZONE_FILL = ("#D6EBD8", "#EDF6CE", "#FFF7C4", "#FFE2BF", "#FBD2D2")


def _pyplot():
    """Import pyplot with a headless backend already chosen.

    Deferred so that ``--help`` and an import of this module for its constants do not
    require a display or pay matplotlib's start-up cost.
    """
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    return plt


def stage_chip_hex() -> tuple:
    """The stage colours as rendered by the badge, as ``#rrggbb`` strings.

    Deliberately the *rendered* sRGB from :data:`PAD_STAGE_SRGB`, not the hex supplied in
    the specification. Where the two differ the badge shows the former, so printing the
    latter next to a chip would mislabel the very swatch the reader is looking at. Stage 1
    is the only one that differs (#DCE8E8 rendered vs #E2EDF8 supplied) and is footnoted
    on the figure.
    """
    return tuple("#%02X%02X%02X" % tuple(int(c) for c in srgb) for srgb in PAD_STAGE_SRGB)


def stage_band_edges() -> list:
    """Stage bands as ``(lo, hi)`` dose pairs, the last one open-topped."""
    edges = [0.0, *PAD_STAGE_DOSE_BANDS]
    bands = [(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    bands.append((edges[-1], float("inf")))
    return bands


def _band_marker_dose(lo: float, hi: float) -> float:
    """A representative dose inside a band, for placing that band's chip.

    Geometric mean rather than arithmetic: the bands span 0.2 to 40 ppm*hr, so the
    arithmetic midpoint of the widest band lands almost at its top edge and the chip
    stops looking like it belongs to the band.
    """
    hi_eff = min(hi, DOSE_MAX) if np.isfinite(hi) else DOSE_MAX
    lo_eff = max(lo, 0.05)
    return float(np.sqrt(lo_eff * hi_eff))


def _band_text(lo: float, hi: float) -> str:
    """Human-readable dose band, e.g. ``1.5-8.0`` or ``>40.0``."""
    if not np.isfinite(hi):
        return f">{lo:.1f}"
    return f"{lo:.1f}-{hi:.1f}"


def _stage_ribbon(ax, chips, bands):
    """The stage ladder as a colour ribbon along the dose axis.

    This replaces per-stage chips drawn on the curve. Chips on the curve cannot work on a
    linear 0-50 axis: stages 1 and 2 together span 0-1.5 ppm*hr, so their markers land
    within a couple of pixels and their captions overlap, while stage 5 (>40) sits in the
    top-right corner underneath whatever else is there.

    The ribbon has no such failure mode, and says more: each segment spans exactly its dose
    band, so the reader sees directly that the SAFE band is a sliver and WARNING is most of
    the axis. That the low bands look cramped is not a drawing artefact - it is the
    specification's sensitivity claim, drawn to scale.
    """
    from matplotlib.patches import Rectangle
    from matplotlib.transforms import blended_transform_factory

    # Self-check before drawing: a dose inside segment i must be classified as stage i+1 by
    # the same function the reader calls. Cheap, and it catches the one failure that would
    # otherwise be invisible - a ribbon that looks authoritative while disagreeing with the
    # verdict the badge actually issues.
    for i, (lo, hi) in enumerate(bands):
        probe = _band_marker_dose(lo, hi)
        got = stage_for_dose(probe)["stage"]
        if got != i + 1:
            raise ValueError(
                f"stage ribbon disagrees with engine.dosimetry.stage_for_dose: "
                f"{probe:.4g} ppm*hr is drawn in segment {i + 1} but classified as "
                f"stage {got}. The band table and this figure have diverged.")

    tr = blended_transform_factory(ax.transData, ax.transAxes)
    y0, h = 0.008, 0.042

    for i, ((lo, hi), hexcol) in enumerate(zip(bands, chips)):
        hi_eff = min(hi, DOSE_MAX) if np.isfinite(hi) else DOSE_MAX
        if lo >= DOSE_MAX:
            break
        ax.add_patch(Rectangle((lo, y0), hi_eff - lo, h, transform=tr,
                               facecolor=hexcol, edgecolor="#212121", linewidth=0.8,
                               zorder=11, clip_on=True))
        # Label only the segments with room for text; the narrow low bands are bracketed.
        if (hi_eff - lo) / (DOSE_MAX - DOSE_MIN) > 0.10:
            lum = sum(int(hexcol[j:j + 2], 16) for j in (1, 3, 5)) / 3.0
            ax.text((lo + hi_eff) / 2.0, y0 + h / 2.0, f"S{i + 1}", transform=tr,
                    fontsize=6.8, fontweight="bold", ha="center", va="center", zorder=12,
                    color="#FFFFFF" if lum < 110 else "#212121")

    narrow = PAD_STAGE_DOSE_BANDS[1]
    ax.annotate("S1-S2\n" + rf"0-{narrow:.1f} ppm$\cdot$hr",
                xy=(narrow * 0.5, y0 + h), xycoords=tr,
                xytext=(28, 34), textcoords="offset points",
                fontsize=6.4, ha="center", va="bottom", color="#212121", zorder=12,
                arrowprops=dict(arrowstyle="-", color="#616161", lw=0.8,
                                shrinkA=0.0, shrinkB=1.0),
                bbox=dict(boxstyle="round,pad=0.2", fc="#FFFFFF", ec="#BDBDBD", lw=0.7,
                          alpha=0.95))

    ax.text(DOSE_MAX * 0.995, y0 + h + 0.012, "stage ladder, drawn to dose scale",
            transform=tr, fontsize=6.0, color="#546E7A", ha="right", va="bottom",
            zorder=12)


def _panel_saturation(ax):
    """The approach to saturation, well beyond the badge's useful range.

    The main panel covers 0-50 ppm*hr, where response is close to proportional to dose - a
    genuinely useful property, and the reason a near-straight line there is not a defect.
    Shown alone it would hide that this is saturating chemistry, and anyone who knows
    Langmuir kinetics will ask where the knee is. This panel answers before the question is
    put, and marks the two ceilings that change what the reader is willing to say.
    """
    d = np.linspace(0.0, INSET_DOSE_MAX, 700)
    y = np.array([DEFAULT_CALIBRATION.observable_for_dose(x) for x in d])
    ax.plot(d, y, color="#0D47A1", lw=2.2, zorder=4)

    ax.axvspan(0.0, DOSE_MAX, color="#0D47A1", alpha=0.09, zorder=0)
    ax.text(DOSE_MAX * 0.52, float(y.max()) * 0.035, "range of main panel",
            fontsize=6.4, color="#0D47A1", ha="center", va="bottom", rotation=90)

    inv_max = float(SATURATION_CALIBRATION.obs_max)
    ax.axhline(inv_max, color="#00897B", lw=1.4, ls=(0, (5, 2)), zorder=5)
    ax.text(INSET_DOSE_MAX * 0.52, inv_max + 1.0,
            f"inverse valid below  " + rf"$-\Delta L^*$ = {inv_max:.1f}",
            fontsize=6.6, color="#00695C", ha="center", va="bottom")

    pad_sat = float(SATURATION_CALIBRATION.obs_saturation)
    ax.axhline(pad_sat, color="#6A1B9A", lw=1.2, ls=":", zorder=5)
    ax.text(INSET_DOSE_MAX * 0.52, pad_sat + 1.0,
            f"pad optically saturated  " + rf"$-\Delta L^*$ = {pad_sat:.1f}",
            fontsize=6.6, color="#6A1B9A", ha="center", va="bottom")

    ax.set_title("Approach to saturation\n"
                 + rf"$d_{{char}}$ = {55.0:.0f} ppm$\cdot$hr  (inherited, unrefitted)",
                 fontsize=8.6, pad=8)
    ax.set_xlabel(r"dose (ppm$\cdot$hr)", fontsize=8.2, labelpad=5)
    ax.set_ylabel(r"$-\Delta L^*$", fontsize=8.2, labelpad=4)
    ax.tick_params(labelsize=7.2)
    ax.set_xlim(0.0, INSET_DOSE_MAX)
    ax.set_ylim(0.0, pad_sat * 1.22)
    ax.grid(True, ls=":", alpha=0.5, zorder=1)
    ax.set_facecolor("#FAFAFA")


def _panel_curve(ax) -> None:
    """Dose vs. -dL*: the analytic forward model, the fitted inverse, the stage ladder."""
    chips = stage_chip_hex()
    bands = stage_band_edges()

    # --- exposure zones, edges taken from the stage table ------------------------------
    for i, (lo, hi) in enumerate(bands):
        hi_eff = min(hi, DOSE_MAX) if np.isfinite(hi) else DOSE_MAX
        if lo >= DOSE_MAX:
            break
        ax.axvspan(lo, hi_eff, color=_ZONE_FILL[i], alpha=0.72, zorder=0)

    # --- the physics: analytic forward model, no fitting anywhere in it ----------------
    d = np.linspace(DOSE_MIN, DOSE_MAX, 900)
    y_true = np.array([DEFAULT_CALIBRATION.observable_for_dose(x) for x in d])
    curve_h, = ax.plot(d, y_true, color="#0D47A1", linewidth=2.8, zorder=4,
                       label=r"Forward model $-\Delta L^*(D)$  (reflectance blend, "
                             r"analytic)")

    # --- the inverse actually used to read a badge, over its declared validity band ----
    d_sat = np.linspace(0.5, 40.0, 400)
    y_sat = np.array([SATURATION_CALIBRATION.observable_for_dose(x) for x in d_sat])
    inv_h, = ax.plot(d_sat, y_sat, color="#00897B", linewidth=1.9,
                     linestyle=(0, (5, 2)), zorder=5,
                     label=r"Hill/Langmuir inverse  (fit band 0.5-40 ppm$\cdot$hr, "
                           r"2.1% rms)")

    # --- the TLV decision point, computed not asserted ---------------------------------
    tlv_dose = ACGIH_OSHA_NIOSH.twa_ppm * SHIFT_HOURS
    tlv_y = float(DEFAULT_CALIBRATION.observable_for_dose(tlv_dose))
    ax.plot([tlv_dose, tlv_dose], [0.0, tlv_y], color="#E65100", ls="--", lw=1.6, zorder=6)
    ax.plot([0.0, tlv_dose], [tlv_y, tlv_y], color="#E65100", ls="--", lw=1.6, zorder=6)
    ax.scatter([tlv_dose], [tlv_y], color="#E65100", s=80, zorder=7)
    ax.annotate(
        r"$\bf{ACGIH\ TLV\text{-}TWA\ 1\ ppm}$"
        "\n"
        rf"$8.0\ \mathrm{{ppm}}\cdot\mathrm{{hr}}$ over {SHIFT_HOURS:.0f} h"
        "\n"
        rf"$-\Delta L^* = {tlv_y:.2f}$",
        xy=(tlv_dose, tlv_y), xytext=(24.0, 2.1),
        arrowprops=dict(arrowstyle="->", color="#E65100", lw=1.5),
        fontsize=8.5, color="#BF360C", zorder=8,
        bbox=dict(boxstyle="round,pad=0.3", fc="#FFFFFF", ec="#E65100", lw=1.2))

    # --- the critical dose, the other line an inspector cares about ---------------------
    crit = float(ACGIH_OSHA_NIOSH.dose_critical_ppm_hr)
    ax.axvline(crit, color="#B71C1C", lw=1.4, ls=":", zorder=6)
    ax.text(crit - 0.7, float(y_true.max()) * 0.99,
            f"critical dose {crit:.0f} " + r"ppm$\cdot$hr",
            fontsize=7.2, color="#B71C1C", va="top", ha="right", rotation=90, zorder=8)

    ax.set_xlabel(r"$\bf{Cumulative\ H_2S\ dose\ (ppm\cdot hr)}$", fontsize=10.0,
                  labelpad=7)
    ax.set_ylabel(r"$\bf{Lightness\ drop\ }-\Delta L^*\ \bf{[CIELAB,\ D65]}$",
                  fontsize=10.0, labelpad=7)
    ax.set_xlim(DOSE_MIN, DOSE_MAX)
    ax.set_ylim(0.0, float(y_true.max()) * 1.06)
    ax.grid(True, linestyle=":", alpha=0.55, zorder=1)
    ax.set_facecolor("#FAFAFA")

    _stage_ribbon(ax, chips, bands)

    # Two legends: the model curves at lower right, the stage ladder at upper left. Adding
    # the second replaces the first unless the first is re-attached as an artist.
    curves_leg = ax.legend([curve_h, inv_h],
                           [curve_h.get_label(), inv_h.get_label()],
                           loc="lower right", framealpha=0.96, fontsize=7.6,
                           bbox_to_anchor=(1.0, 0.075))
    ax.add_artist(curves_leg)
    _stage_ladder_legend(ax, chips, bands)


def _stage_ladder_legend(ax, chips, bands):
    """The five stage chips as a compact legend block, not inline annotations.

    Inline labels were tried first and do not work here: stages 1 and 2 span 0-1.5 ppm*hr,
    so on a 0-50 axis their chips land within a few pixels of each other and their captions
    overlap, while stage 5's caption runs off the right edge. Moving the whole ladder into
    one anchored block removes every collision at once and has room for the band edges and
    hex values, which the inline version had no space for.
    """
    from matplotlib.patches import Rectangle

    handles, labels = [], []
    for i, ((lo, hi), hexcol) in enumerate(zip(bands, chips)):
        star = "*" if hexcol.upper() != SUPPLIED_STAGE_HEX_UNCORRECTED[i].upper() else ""
        handles.append(Rectangle((0, 0), 1, 1, facecolor=hexcol, edgecolor="#212121",
                                 linewidth=0.9))
        labels.append(f"S{i + 1}  {_band_text(lo, hi):>10s}  {hexcol}{star}   "
                      f"{PAD_STAGE_LABELS[i]}")

    title = "CuS stage ladder  (ppm$\\cdot$hr, rendered hex)"
    if not STAGE_TABLE_IS_VALIDATED:
        title += "  -  PROVISIONAL"
    leg = ax.legend(handles, labels, loc="upper left", fontsize=7.0,
                    title=title, title_fontsize=7.6, framealpha=0.96,
                    handlelength=1.5, handleheight=1.15, labelspacing=0.45,
                    borderpad=0.6)
    leg.get_title().set_fontweight("bold")
    leg._legend_box.align = "left"
    return leg


def _footnotes(fig) -> None:
    """The three things a reader needs to not over-trust this figure.

    Figure-level rather than axes-level, because the caveats apply to both panels and an
    axes-anchored text block moves whenever a panel is resized.
    """
    chips = stage_chip_hex()
    lines = [
        f"Unexposed baseline L* = {UNEXPOSED_PAD_LAB[0]:.2f}. Observable is -dL*, chosen "
        f"over dE00 and locus projection on measured accuracy (4.9% vs 11.6% vs 6.8% rms).",
        f"Above -dL* = {float(SATURATION_CALIBRATION.obs_max):.2f} (about 40 ppm*hr) the "
        f"reader reports EXTRAPOLATED rather than quoting a dose; the pad itself does not "
        f"saturate until {float(SATURATION_CALIBRATION.obs_saturation):.1f}.",
        f"Reagent: {REAGENT_NAME}; product: {REACTION_PRODUCT_NAME}; "
        f"{REACTION_EQUATION}. Every value plotted is read from engine/ at import time.",
    ]
    if any(c.upper() != s.upper()
           for c, s in zip(chips, SUPPLIED_STAGE_HEX_UNCORRECTED)):
        lines.append(
            f"* rendered sRGB differs from the hex given in the specification (stage 1: "
            f"{chips[0]} vs {SUPPLIED_STAGE_HEX_UNCORRECTED[0]}); the badge prints the "
            f"rendered value, so that is what is shown here.")
    fig.text(0.012, 0.088, "\n".join(lines), fontsize=6.9, color="#37474F",
             va="top", ha="left", linespacing=1.55)


def _provisional_banner(fig) -> None:
    """Stamp the figure when the dose bands are still unvalidated.

    The stage table's implied sensitivity needs ``d_char`` near 3 where the model uses 55
    - roughly 18x - so the band edges are a specification claim, not a measurement. The
    banner is gated on the engine's own flag, so it disappears by itself the day a chamber
    campaign flips :data:`STAGE_TABLE_IS_VALIDATED`.
    """
    if STAGE_TABLE_IS_VALIDATED:
        return
    fig.text(0.5, 0.012,
             "PROVISIONAL - dose band edges are specification targets, not chamber-"
             "validated. Colour ladder is specified; kinetics are modelled from "
             "acetate-era d_char = 55 ppm*hr.",
             ha="center", va="bottom", fontsize=7.4, color="#B71C1C", fontweight="bold",
             bbox=dict(boxstyle="round,pad=0.35", fc="#FFF5F5", ec="#B71C1C", lw=1.1))


def make_calibration_figure(dpi: float = 300.0):
    """Build and return the calibration figure: operating range beside full saturation."""
    plt = _pyplot()
    fig, (ax_main, ax_sat) = plt.subplots(
        1, 2, figsize=(13.0, 7.4), dpi=dpi,
        gridspec_kw=dict(width_ratios=(2.15, 1.0), wspace=0.185))
    fig.patch.set_facecolor("#FFFFFF")

    _panel_curve(ax_main)
    _panel_saturation(ax_sat)

    fig.suptitle(TITLE + "\n"
                 + r"Lightness loss $-\Delta L^*$ vs. cumulative dose      "
                 + REACTION_EQUATION,
                 fontsize=12.0, y=0.975)
    fig.subplots_adjust(left=0.062, right=0.988, top=0.855, bottom=0.185)
    _footnotes(fig)
    _provisional_banner(fig)
    return fig


def write_comparator_card(path: str, dpi: float = 300.0) -> bool:
    """Write the pocket comparator card by delegating to the badge renderer.

    Deliberately *not* a second matplotlib drawing of five rectangles. ``render_card`` in
    :mod:`badge.make_badge` already produces this card at the badge's own pad diameter
    with millimetre-specified type and an overflow guard. Reimplementing it here would
    create a second comparator in the project, free to drift from the first - and the two
    would be compared to the same physical badge.

    Returns ``False`` if OpenCV is unavailable, so the caller can report honestly rather
    than emit a success line for a file that was never written.
    """
    try:
        import cv2

        from badge.make_badge import render_card
    except Exception as exc:  # pragma: no cover - environment dependent
        print(f"[!] comparator_card skipped ({type(exc).__name__}: {exc})",
              file=sys.stderr)
        return False

    img = render_card(dpi=float(dpi))
    if not cv2.imwrite(path, img):
        print(f"[!] comparator_card could not be written to {path}", file=sys.stderr)
        return False
    return True


def _display_path(path: str) -> str:
    """Shortest unambiguous form of an output path, for the console line.

    Relative when the file is under the working directory, absolute otherwise. A bare
    ``os.path.relpath`` produced ``../../../../../tmp/fig/calibration_curve.png`` for
    ``--outdir /tmp/fig``, which is both longer and harder to read than the absolute path.
    """
    try:
        rel = os.path.relpath(path, os.getcwd())
    except ValueError:  # different drive on Windows
        return path
    return path if rel.startswith(os.pardir) else rel


def generate_assets(outdir: str = None, dpi: float = 300.0, fmt: str = "png") -> list:
    """Generate both presentation assets. Returns the paths written.

    Signature and default output location match the previous version of this script, so
    any slide pipeline or make target that called ``generate_assets()`` keeps working.
    """
    out_dir = os.path.abspath(outdir or os.path.join(os.getcwd(), "out"))
    os.makedirs(out_dir, exist_ok=True)
    plt = _pyplot()

    written = []

    curve_path = os.path.join(out_dir, f"calibration_curve.{fmt}")
    fig = make_calibration_figure(dpi=dpi)
    fig.savefig(curve_path, dpi=dpi, facecolor=fig.get_facecolor())
    plt.close(fig)
    written.append(curve_path)

    card_path = os.path.join(out_dir, "comparator_card.png")
    if write_comparator_card(card_path, dpi=dpi):
        written.append(card_path)

    for p in written:
        print(f"[OK] Generated: {_display_path(p)}")
    return written


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--outdir", default=None,
                    help="output directory (default: ./out)")
    ap.add_argument("--dpi", type=float, default=300.0, help="raster density")
    ap.add_argument("--format", dest="fmt", default="png",
                    choices=("png", "pdf", "svg"),
                    help="calibration curve format (card is always png)")
    args = ap.parse_args(argv)

    written = generate_assets(outdir=args.outdir, dpi=args.dpi, fmt=args.fmt)
    return 0 if len(written) == 2 else 1


if __name__ == "__main__":
    raise SystemExit(main())
